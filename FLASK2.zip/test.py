from sputils import checkline

line = '[21:43] Amelie Lens - The Future [LENSKE]'
result = checkline(line)
print(result)
