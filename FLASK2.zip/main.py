from flask import Flask, redirect, url_for, render_template, request
from sputils import spotify_client, getSpotifyNames

app = Flask(__name__)

@app.route("/",methods=["POST","GET"])
def home():
    if request.method == "POST":
        txt = request.form["nm"]
        songsfound = getSpotifyNames(txt)
        return render_template("index2.html",arr=songsfound)
    else:
        return render_template("index2.html",arr=[])

    
if __name__ == "__main__":

    app.debug = True
    app.run()

